import "./Mint.css"
import { Link } from "react-router-dom"

export default function Mint(){
    return(
        <>
            insert code
        </>
    )
}
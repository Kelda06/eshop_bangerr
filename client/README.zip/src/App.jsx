import AppRoutes from "./pages/AppRoutes"

export default function App() {
  

  return (
    <>
    <div id="app"></div>
     <AppRoutes />
    </>
  )
}